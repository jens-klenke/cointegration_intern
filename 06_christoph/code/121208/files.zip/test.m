%Solve det(A2*t^2 + A1*t + A0) = 0 where:

a2 = [ 1 2; 2 1] ;
a1 = [ 5 8; 10 7 ];
a0 = [ 3 4; 6 5 ];
polymroot([a2;a1;a0])
